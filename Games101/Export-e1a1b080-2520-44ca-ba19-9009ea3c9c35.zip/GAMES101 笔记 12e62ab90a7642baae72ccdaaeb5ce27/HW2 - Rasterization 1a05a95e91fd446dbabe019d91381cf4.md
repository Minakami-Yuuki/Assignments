# HW2 - Rasterization

[Assignment2.zip](HW2%20-%20Rasterization%201a05a95e91fd446dbabe019d91381cf4/Assignment2.zip)