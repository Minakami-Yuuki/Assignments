# Lec 02 - Linear Algebra 向量与线性代数

这节课的笔记比较简略，因为知识比较基础，所以只挑了自己的易错点进行摘录。完全零基础入门的同学建议去看课程视频+参考教材。

---

Graphics’ Dependencies

- Basic mathematics
    - Linear algebra, calculus, statistics
- Basic physics
    - Optics, Mechanics
- Misc
    - Signal processing
    - Numerical analysis
- Aesthetics

图形学中默认向量以一列的矩阵表示（nx1）

一般是右手坐标系

OPENGL是左手坐标系

叉乘：

- 左侧还是右侧（逆时针还是顺时针）
    - 叉乘结果为正/负
- 内侧还是外侧
    - P点一直在三条边的左边/右边

![Lec%2002%20-%20Linear%20Algebra%20%E5%90%91%E9%87%8F%E4%B8%8E%E7%BA%BF%E6%80%A7%E4%BB%A3%E6%95%B0%20458bf8d4bab54b2cb945bad110d4a507/Untitled.png](Lec%2002%20-%20Linear%20Algebra%20%E5%90%91%E9%87%8F%E4%B8%8E%E7%BA%BF%E6%80%A7%E4%BB%A3%E6%95%B0%20458bf8d4bab54b2cb945bad110d4a507/Untitled.png)