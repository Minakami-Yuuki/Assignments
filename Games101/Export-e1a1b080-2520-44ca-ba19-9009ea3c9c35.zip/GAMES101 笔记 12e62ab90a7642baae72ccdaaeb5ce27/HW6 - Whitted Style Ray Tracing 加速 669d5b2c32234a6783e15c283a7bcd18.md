# HW6 - Whitted Style Ray Tracing 加速

[Assignment6.zip](HW6%20-%20Whitted%20Style%20Ray%20Tracing%20%E5%8A%A0%E9%80%9F%20669d5b2c32234a6783e15c283a7bcd18/Assignment6.zip)