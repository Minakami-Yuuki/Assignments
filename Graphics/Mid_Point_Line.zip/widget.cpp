#include "widget.h"
#include <QtGui>

const static int _size = 10000;

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    ptList.reserve(2 * _size);
    //qsrand(time(NULL));
    this->setFixedSize(640, 480);
    int width = this->size().width();
    int height = this->size().height();
    
    for(int i = 0; i < _size; ++i){
        ptList << QPoint(qrand() % width, qrand() % height);
        ptList << QPoint(qrand() % width, qrand() % height);
    }
}

Widget::~Widget()
{

}


void Mid_Point_Line(int x0, int y0, int x1, int y1, QImage& image){

    int a, b, d, d1, d2;
    if(x1 == x0) {
        int ys = y0 < y1 ? y0 : y1;
        int ye = y0 < y1 ? y1 : y0;
        for(int y = ys; y < ye; ++y)
            image.setPixel(x0, y, 0);
            //painter.drawPoint(x0, y);
        return;
    }
    int width = image.width();
    int height = image.height();

    float k = (float)(y1 - y0) / (x1 - x0);
    int y;

    if( 0 <= k && k <= 1) {
        if(x0 > x1) {
            qSwap(x0, x1);
            qSwap(y0, y1);
        }
        a = y0 - y1;
        b = x1 - x0;
        d1 = a + a;
        d = d1 + b;
        d2 = (a + b) << 1;
        image.setPixel(x0, y0, 0);
        //painter.drawPoint(x0, y0);
        int x = x0;
        y = y0;
        while(x < x1){
            if(d < 0) {
                ++y;
                d += d2;
            }
            else {
                d += d1;
            }
            ++x;
            image.setPixel(x, y, 0);
            //painter.drawPoint(x, y);
        }
    }
    else if( k < 0 && k >= -1){
        if(x0 > x1) {
            qSwap(x0, x1);
            qSwap(y0, y1);
        }
        a = y0 - y1;
        b = x1 - x0;
        d1 = a + a;
        d = d1 - b;
        d2 = (a - b) << 1;
        image.setPixel(x0, y0, 0);
        //painter.drawPoint(x0, y0);
        y = y0;
        int x = x0;
        while(x < x1){
            if(d >= 0) {
                ++x;
                --y;
                d += d2;
            }
            else {
                ++x;
                d += d1;
            }
            image.setPixel(x, y, 0);
            //painter.drawPoint(x, y);
        }
    }
    else if ( k > 1){
        if(y0 > y1) {
            qSwap(x0, x1);
            qSwap(y0, y1);
        }
        a = x0 - x1;
        b = y1 - y0;
        d1 = a + a;
        d = d1 + b;
        d2 = (a + b) << 1;
        image.setPixel(x0, y0, 0);
        //painter.drawPoint(x0, y0);
        int x = x0;
        y = y0;
        while(y < y1){
            if(d < 0) {
                ++x;
                ++y;
                d += d2;
            }
            else {
                ++y;
                d += d1;
            }
            image.setPixel(x, y, 0);
            //painter.drawPoint(x, y);
        }
    }
    else if(k < -1){
        if(y0 > y1) {
            qSwap(x0, x1);
            qSwap(y0, y1);
        }
        a = x0 - x1;
        b = y1 - y0;
        d1 = a + a;
        d = d1 - b;
        d2 = (a - b) << 1;
        image.setPixel(x0, y0, 0);
        //painter.drawPoint(x0, y0);
        int x = x0;
        y = y0;
        while(y < y1){
            if(d >= 0) {
                --x;
                ++y;
                d += d2;
            }
            else {
                ++y;
                d += d1;
            }

            image.setPixel(x, y, 0);
            //painter.drawPoint(x, y);
        }
    }
}


void Widget::paintEvent(QPaintEvent *){

    QPainter painter(this);
    QTime time = QTime::currentTime();
    //Mid_Point_Line(startPt.x(), startPt.y(), endPt.x(), endPt.y(), painter);
    QImage image = QImage(this->width(), this->height(), QImage::Format_RGB32);
    image.fill(0xFFFFFFFF);
    //image = QImage(
    //qDebug() << image.size();
//    for(int i = 0; i < _size ; i += 2){
//        QPoint startPt = ptList.at(i);
//        QPoint endPt = ptList.at(i + 1);
        Mid_Point_Line(startPt.x(), startPt.y(), endPt.x(), endPt.y(), image);
 //   }
    painter.drawImage(0,0,image);
    painter.setPen(Qt::red);
    painter.drawText(20,20, QString("FPS:%1").arg(1000./time.elapsed()));
    //
    

}


void Widget::mousePressEvent(QMouseEvent *event){
    startPt = event->pos();
    //qDebug() << startPt;
}

void Widget::mouseReleaseEvent(QMouseEvent *event){
    endPt = event->pos();
    update();
}


void Widget::mouseMoveEvent(QMouseEvent *event){
    endPt = event->pos();
    update();
}
