#include "widget.h"
#include <QtGui>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    isDrawing = false;

}

Widget::~Widget()
{

}


void Mid_Point_Circle(int x0, int y0, int r, QPainter& painter){
    
    int d = 1 - r;
    //painter.drawPoint(0 + x0, r + y0);
    //int d1 = 3, d2 = 2 - (r << 1);
    for(int x = 0, y = r; x <= y; ++x) {
        painter.drawPoint(QPoint(x, y) + QPoint(x0, y0));
        painter.drawPoint(QPoint(-x, y) + QPoint(x0, y0));
        painter.drawPoint(QPoint(-x, -y) + QPoint(x0, y0));
        painter.drawPoint(QPoint(x, -y) + QPoint(x0, y0));
        painter.drawPoint(QPoint(y, x) + QPoint(x0, y0));
        painter.drawPoint(QPoint(-y, x) + QPoint(x0, y0));
        painter.drawPoint(QPoint(-y, -x) + QPoint(x0, y0));
        painter.drawPoint(QPoint(y, -x) + QPoint(x0, y0));
        if(d < 0) {
            d += 2 * x + 3;
        }
        else {
            d += 2 * (x - y) + 5;
            --y;
        }

    }
}


void Widget::paintEvent(QPaintEvent *event){

    QPainter painter(this);
    //qDebug() << QVector2D(startPt).distanceToPoint(QVector2D(endPt));
    if(isDrawing)
        painter.drawLine(startPt, endPt);
    int d = QVector2D(startPt).distanceToPoint(QVector2D(endPt));
    //painter.drawEllipse(startPt, d, d );
    Mid_Point_Circle(startPt.x(), startPt.y(), QVector2D(startPt).distanceToPoint(QVector2D(endPt)) + 0.5, painter);
    //Mid_Point_Line(50, 50, 100, 25, painter);
    //painter.drawLine(QPoint(50,50), QPoint(200, 100));

}


void Widget::mousePressEvent(QMouseEvent *event){
    startPt = event->pos();
    isDrawing = true;
    //qDebug() << startPt;
}

void Widget::mouseReleaseEvent(QMouseEvent *event){
    endPt = event->pos();
    isDrawing = false;
    update();
}


void Widget::mouseMoveEvent(QMouseEvent *event){
    endPt = event->pos();
    update();
}
