#include "bezier.h"
#include <iostream>

Bezier::Bezier(QWidget *parent)
    : QWidget(parent)
{
    ptPen.setColor(Qt::green);
    ptPen.setBrush(Qt::SolidPattern);
    ptPen.setWidthF(5);

    straightLinePen.setWidth(1);
    straightLinePen.setColor(Qt::lightGray);
    
    tList.reserve(4000);
    for(int t = 0; t < 1000; ++t){
        float _t = t / 1000.;
        tList.push_back( (1 - _t) * (1 - _t) * (1 - _t));
        tList << (1 - _t) * (1 - _t) * _t * 3;
        tList << (1 - _t) * _t * _t * 3;
        tList << _t * _t * _t;
    }
    bDrawing = true;
    selectedPtIdx = -1;

}

Bezier::~Bezier()
{

}

void Bezier::mouseReleaseEvent(QMouseEvent *event)
{
    if(event->button() == Qt::RightButton){
        if(bDrawing)
            bDrawing = false;
    }
    if(bDrawing){
        if(ptList.size() < 4)
            ptList.append(event->pos());
        else if( (ptList.size() - 1) % 3 == 0){
            ptList.append(2 * ptList.last() - ptList.at(ptList.size() - 2));
            ptList.append(event->pos());
        }
        else {
            ptList.append(event->pos());
        }
    }
    update();

}

void Bezier::mouseMoveEvent(QMouseEvent *event){
    if(selectedPtIdx < 0)
        return;
    if(event->modifiers() == Qt::SHIFT){
        if(selectedPtIdx % 3 == 0) {
            if(selectedPtIdx == 0)
                ptList[selectedPtIdx] = event->pos();
            else if(selectedPtIdx == ptList.size() - 1){
                
            }
            else {
                QPointF offset = event->pos() - ptList.at(selectedPtIdx) ;
                ptList[selectedPtIdx] = event->pos();
                ptList[selectedPtIdx - 1] += offset;
                ptList[selectedPtIdx + 1] += offset;
                
            }
        }
        else if (selectedPtIdx % 3 == 2 || selectedPtIdx % 3 == 1) {
            if(selectedPtIdx < 2){
                ptList[selectedPtIdx] = event->pos();
            }
            else {
                int smallIdx = selectedPtIdx % 3 == 2 ? selectedPtIdx : selectedPtIdx - 2;
                selectedPtIdx = smallIdx == selectedPtIdx ? smallIdx + 2 : selectedPtIdx;
                ptList[smallIdx] = event->pos();
                QPointF mid = ptList.at(smallIdx + 1);
                ptList[selectedPtIdx] = 2 * mid - event->pos();
            }
        }
        else
            ptList[selectedPtIdx] = event->pos();
        
    }
    else {
        ptList[selectedPtIdx] = event->pos();
    }
    update();
    
}

void Bezier::mousePressEvent(QMouseEvent *event){
    if(bDrawing == false && event->button() ==  Qt::LeftButton){
        QPoint pt = event->pos();
        for(int i = 0; i < ptList.size(); ++i){
            if(QVector2D(pt).distanceToPoint(QVector2D(ptList.at(i))) < 3)
                selectedPtIdx = i;
        }
        
    }
}

void Bezier::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);

    painter.setPen(ptPen);
    for(int i = 0; i < ptList.size(); ++i)
        painter.drawPoint(ptList.at(i));

    painter.setPen(straightLinePen);
    for(int i = 0; i < ptList.size() - 1; ++i){
        painter.drawLine(ptList.at(i), ptList.at(i + 1));
    }
    if(ptList.size() < 4)
        return;
    painter.setPen(Qt::red);
    int l = (ptList.size() - 1) / 3;
    for(int k = 0; k < l; ++k){
        for(int t = 0; t < 1000; ++t){
            painter.drawPoint( ptList.at(k * 3) * tList[t * 4 + 0] + ptList.at(k * 3 + 1) * tList[t * 4 + 1] +
                              ptList.at(k * 3 + 2) * tList[t * 4 + 2] + ptList.at(k * 3 + 3) * tList[t * 4 + 3] );
            
        }
    }
    


}
