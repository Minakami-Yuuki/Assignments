#ifndef BEZIER_H
#define BEZIER_H

#include <QWidget>
#include <QtWidgets>

class Bezier : public QWidget
{
    Q_OBJECT

public:
    Bezier(QWidget *parent = 0);
    ~Bezier();

private:
    QVector<QPointF> ptList;

    QPen ptPen;
    QPen straightLinePen;
    
    QVector<float> tList;
    bool bDrawing;
    int selectedPtIdx;

protected:
    void mouseReleaseEvent(QMouseEvent *);
    void mousePressEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *);
    void paintEvent(QPaintEvent *);
};

#endif // BEZIER_H
